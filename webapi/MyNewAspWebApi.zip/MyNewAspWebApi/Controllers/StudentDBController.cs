﻿using MyNewAspWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyNewAspWebApi.Controllers
{
    public class StudentDBController : ApiController
    {
        DotNetEntities db = new DotNetEntities();

        [System.Web.Http.HttpGet]
        public IHttpActionResult Index()
        {
            List<Student> obj = db.Students.ToList();
            return Ok(obj);
        }
        [System.Web.Http.HttpGet]
        public IHttpActionResult Index(int id)
        {
            var obj = db.Students.Where(model => model.Id == id).FirstOrDefault();
            return Ok(obj);
        }
    }
}
